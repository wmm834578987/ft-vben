<script lang="ts" setup>
defineOptions({ name: 'FrameBlank' })
</script>

<template>
  <div />
</template>
