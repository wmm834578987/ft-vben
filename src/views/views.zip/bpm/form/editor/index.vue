<script lang="ts" setup>
import { VFormDesign } from '@/components/FormDesign'
</script>

<template>
  <div>
    <VFormDesign />
  </div>
</template>
