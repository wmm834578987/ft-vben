import wxAccountSelect from './WxAccountSelect/index.vue'

export { wxAccountSelect }
